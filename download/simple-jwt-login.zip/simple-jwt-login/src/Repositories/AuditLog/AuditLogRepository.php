<?php

namespace SimpleJWTLogin\Repositories\AuditLog;

use SimpleJWTLogin\Repositories\DateFilterTrait;

class AuditLogRepository implements Repository
{
    use DateFilterTrait;

    const TABLE_SUFFIX = 'simple_jwt_login_audit_logs';

    /**
     * Group-by expression, failure rows only, order clause. Never built from input.
     *
     * @var array<string, array{0: string, 1: bool, 2: string}>
     */
    private static $dimensions = array(
        'event'           => array('logs.event_type', false, 'total DESC'),
        'hour'            => array('LEFT(logs.created_at, 13)', false, 'bucket ASC'),
        'day'             => array('LEFT(logs.created_at, 10)', false, 'bucket ASC'),
        'failure_ip'      => array('logs.ip_address', true, 'total DESC'),
        'failure_user'    => array('logs.user_id', true, 'total DESC'),
        'failure_api_key' => array('logs.api_key_id', true, 'total DESC'),
        'failure_message' => array('LEFT(logs.message, 200)', true, 'total DESC'),
    );

    /**
     * @var \wpdb
     */
    private $wpdb;

    /**
     * @param \wpdb $wpdb
     */
    public function __construct($wpdb)
    {
        $this->wpdb = $wpdb;
    }

    /**
     * @return string
     */
    private function tableName()
    {
        return $this->wpdb->prefix . self::TABLE_SUFFIX;
    }

    /**
     * @param string      $eventType
     * @param int|null    $userId
     * @param string|null $ipAddress
     * @param string      $status
     * @param string|null $message
     * @param int|null    $apiKeyId
     * @return bool
     */
    public function insert($eventType, $userId, $ipAddress, $status, $message, $apiKeyId = null)
    {
        $result = $this->wpdb->insert(
            $this->tableName(),
            [
                'event_type'  => $eventType,
                'user_id'     => $userId,
                'ip_address'  => $ipAddress,
                'status'      => $status,
                'message'     => $message,
                'api_key_id'  => $apiKeyId,
            ],
            ['%s', '%d', '%s', '%s', '%s', '%d']
        );

        return $result !== false;
    }

    /**
     * @param array $filters
     * @param int   $page
     * @param int   $perPage
     * @return array
     */
    public function findPaginated($filters, $page, $perPage)
    {
        $where  = [];
        $params = [];

        if (!empty($filters['event_type'])) {
            $where[]  = 'logs.event_type = %s';
            $params[] = $filters['event_type'];
        }

        if (!empty($filters['status'])) {
            $where[]  = 'logs.status = %s';
            $params[] = $filters['status'];
        }

        if (!empty($filters['user_id'])) {
            $where[]  = 'logs.user_id = %d';
            $params[] = (int) $filters['user_id'];
        }

        if (!empty($filters['user_email'])) {
            $where[]  = 'users.user_email LIKE %s';
            $params[] = '%' . $this->wpdb->esc_like($filters['user_email']) . '%';
        }

        if (!empty($filters['date_from']) && $this->isValidDate($filters['date_from'])) {
            $where[]  = 'logs.created_at >= %s';
            $params[] = $filters['date_from'] . ' 00:00:00';
        }

        if (!empty($filters['date_to']) && $this->isValidDate($filters['date_to'])) {
            $where[]  = 'logs.created_at <= %s';
            $params[] = $filters['date_to'] . ' 23:59:59';
        }

        $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
        $fromClause  = 'FROM %i logs LEFT JOIN %i users ON logs.user_id = users.ID ' . $whereClause;

        $offset = ($page - 1) * $perPage;

        $countSql    = 'SELECT COUNT(*) ' . $fromClause;
        $dataSql     = 'SELECT logs.*, users.user_email AS user_email ' . $fromClause
            . ' ORDER BY logs.created_at DESC LIMIT %d OFFSET %d';
        $countParams = array_merge([$this->tableName(), $this->wpdb->users], $params);
        $dataParams  = array_merge([$this->tableName(), $this->wpdb->users], $params, [$perPage, $offset]);

        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $preparedCountSql = $this->wpdb->prepare($countSql, $countParams);
        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter
        $total = (int) $this->wpdb->get_var($preparedCountSql);
        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter
        $items = $this->wpdb->get_results($this->wpdb->prepare($dataSql, $dataParams));

        return [
            'items' => $items !== null ? $items : [],
            'total' => $total,
        ];
    }

    /**
     * @param string $dimension
     * @param int    $hours
     * @param int    $limit
     * @return object[]
     */
    public function aggregate($dimension, $hours, $limit)
    {
        if (!isset(self::$dimensions[$dimension])) {
            return [];
        }
        list($expression, $failureOnly, $orderBy) = self::$dimensions[$dimension];

        $where = 'logs.created_at >= DATE_SUB(NOW(), INTERVAL %d HOUR) AND ' . $expression . ' IS NOT NULL';
        if ($failureOnly) {
            $where .= " AND logs.status = 'failure'";
        }

        $sql = 'SELECT ' . $expression . ' AS bucket, logs.status AS status, COUNT(*) AS total,'
            . ' COUNT(DISTINCT logs.user_id) AS users, MAX(logs.created_at) AS last_seen,'
            . ' MAX(users.user_email) AS user_email'
            . ' FROM %i logs LEFT JOIN %i users ON logs.user_id = users.ID'
            . ' WHERE ' . $where
            . ' GROUP BY bucket, logs.status ORDER BY ' . $orderBy . ' LIMIT %d';
        $params = [$this->tableName(), $this->wpdb->users, (int) $hours, (int) $limit];

        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter
        $rows = $this->wpdb->get_results($this->wpdb->prepare($sql, $params));

        return is_array($rows) ? $rows : [];
    }

    /**
     * @param string $beforeDatetime
     * @return bool
     */
    public function deleteOlderThan($beforeDatetime)
    {
        $sql = $this->wpdb->prepare(
            'DELETE FROM %i WHERE created_at < %s',
            $this->tableName(),
            $beforeDatetime
        );
        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $this->wpdb->query($sql);

        return $result !== false;
    }

    /**
     * @return bool
     */
    public function deleteAll()
    {
        $escapedTable = esc_sql($this->tableName());
        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $this->wpdb->query('DELETE FROM `' . $escapedTable . '`');

        return $result !== false;
    }

    /**
     * @return bool
     */
    public function dropTable()
    {
        $escapedTable = esc_sql($this->tableName());
        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.DirectDatabaseQuery.NoCaching
        $result = $this->wpdb->query('DROP TABLE IF EXISTS `' . $escapedTable . '`');

        return $result !== false;
    }

    /**
     * @return void
     */
    public function createTable()
    {
        $charsetCollate = $this->wpdb->get_charset_collate();
        $tableName      = $this->tableName();

        $sql = "CREATE TABLE $tableName (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            event_type varchar(100) NOT NULL,
            user_id bigint(20) DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'success',
            message text DEFAULT NULL,
            api_key_id bigint(20) DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_event_created (event_type, created_at),
            KEY idx_user_created (user_id, created_at),
            KEY idx_status_created (status, created_at),
            KEY idx_apikey_created (api_key_id, created_at),
            KEY created_at (created_at)
        ) $charsetCollate;";

        if (!function_exists('dbDelta')) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        }
        dbDelta($sql);

        $this->dropLegacyUserEmailColumn();
    }

    /**
     * Drop the legacy user_email column on existing installs. dbDelta never
     * removes columns, so this runs explicitly after the table is created.
     *
     * @return void
     */
    private function dropLegacyUserEmailColumn()
    {
        $columnSql = $this->wpdb->prepare(
            'SELECT COUNT(*) FROM information_schema.COLUMNS '
            . 'WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s',
            $this->tableName(),
            'user_email'
        );
        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $columnExists = (int) $this->wpdb->get_var($columnSql);
        if ($columnExists === 0) {
            return;
        }

        $escapedTable = esc_sql($this->tableName());
        //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.DirectDatabaseQuery.NoCaching
        $this->wpdb->query('ALTER TABLE `' . $escapedTable . '` DROP COLUMN `user_email`');
    }
}
