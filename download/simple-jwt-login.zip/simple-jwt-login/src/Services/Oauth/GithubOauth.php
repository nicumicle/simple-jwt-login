<?php

namespace SimpleJWTLogin\Services\Oauth;

use Exception;
use SimpleJWTLogin\ErrorCodes;
use SimpleJWTLogin\Libraries\ServerCall;

/**
 * GitHub OAuth2 provider.
 *
 * Supports three flows:
 *  1. Browser OAuth redirect - exchange authorization code via the WP login page button.
 *  2. Code exchange (API)   - POST ?provider=github&code={code} -> returns raw token response.
 *  3. Token exchange (API)  - POST ?provider=github&access_token={token} -> returns a WP JWT.
 *     The token must have been issued for the configured GitHub OAuth app.
 *
 * GitHub's token endpoint returns JSON only when Accept: application/json is sent,
 * so exchangeCode is overridden to include that header.
 * Email is retrieved from GET /user/emails (requires the "user:email" scope).
 */
class GithubOauth extends AbstractOauth
{
    const PROVIDER_SLUG      = 'github';
    const AUTH_URL           = 'https://github.com/login/oauth/authorize';
    const TOKEN_ENDPOINT     = 'https://github.com/login/oauth/access_token';
    const USERINFO_ENDPOINT  = 'https://api.github.com/user/emails';
    const USER_AGENT         = 'simple-jwt-login';
    const CHECK_TOKEN_ENDPOINT_TPL = 'https://api.github.com/applications/%s/token';

    // -------------------------------------------------------------------------
    // AbstractOauth hooks
    // -------------------------------------------------------------------------

    protected function getTokenEndpoint()
    {
        return self::TOKEN_ENDPOINT;
    }

    public function getAuthUrl()
    {
        return self::AUTH_URL;
    }

    protected function getAuthScope()
    {
        return 'user:email';
    }

    protected function getClientId()
    {
        return $this->settings->getIntegrationsSettings()->github()->getClientId();
    }

    protected function getClientSecret()
    {
        return $this->settings->getIntegrationsSettings()->github()->getClientSecret();
    }

    protected function getSavedRedirectUri()
    {
        return $this->settings->getIntegrationsSettings()->github()->getExchangeCodeRedirectUri();
    }

    protected function getProviderSlug()
    {
        return self::PROVIDER_SLUG;
    }

    protected function isCreateUserEnabled()
    {
        return $this->settings->getIntegrationsSettings()->github()->isCreateUserIfNotExistsEnabled();
    }

    /**
     * GitHub's token endpoint returns URL-encoded text by default.
     * Override exchangeCode to request JSON via the Accept header.
     *
     * @param string $code
     * @param string $redirectUri
     * @return array{status_code: int, response: array}
     */
    public function exchangeCode($code, $redirectUri)
    {
        $response = wp_remote_post(
            self::TOKEN_ENDPOINT,
            [
                'headers' => [
                    'Accept'     => 'application/json',
                    'User-Agent' => self::USER_AGENT,
                ],
                'body' => [
                    'client_id'     => $this->getClientId(),
                    'client_secret' => $this->getClientSecret(),
                    'redirect_uri'  => $redirectUri,
                    'code'          => $code,
                ],
            ]
        );

        return [
            'status_code' => (int) wp_remote_retrieve_response_code($response),
            'response'    => json_decode(wp_remote_retrieve_body($response), true),
        ];
    }

    /**
     * @param array $tokenResponse
     * @return string
     * @throws Exception
     */
    protected function getEmailFromTokenResponse($tokenResponse)
    {
        if (empty($tokenResponse['access_token'])) {
            throw new Exception(
                esc_html(__('GitHub did not return an access_token.', 'simple-jwt-login')),
                absint(ErrorCodes::ERR_GITHUB_INVALID_TOKEN)
            );
        }

        return $this->getPrimaryEmailFromGithub($tokenResponse['access_token']);
    }

    /**
     * Validate a GitHub access_token with the "check a token" endpoint of the
     * configured OAuth app. It only answers 200 for tokens issued for that app,
     * so tokens of other apps (and personal access tokens) are rejected.
     *
     * @param string $token
     * @return void
     * @throws Exception
     */
    protected function validateProviderToken($token)
    {
        if (!$this->hasAppCredentials() || !$this->isTokenIssuedForThisApp($token)) {
            throw new Exception(
                esc_html(__('The provided GitHub access_token is invalid.', 'simple-jwt-login')),
                absint(ErrorCodes::ERR_GITHUB_INVALID_TOKEN)
            );
        }
    }

    protected function getInvalidTokenErrorCode()
    {
        return ErrorCodes::ERR_GITHUB_INVALID_TOKEN;
    }

    protected function getUserNotFoundErrorCode()
    {
        return ErrorCodes::ERR_GITHUB_USER_NOT_FOUND;
    }

    protected function getTokenParamName()
    {
        return 'access_token';
    }

    protected function getMissingParamErrorCode()
    {
        return ErrorCodes::ERR_MISSING_GITHUB_PARAM;
    }

    protected function getInvalidCodeErrorCode()
    {
        return ErrorCodes::ERR_GITHUB_INVALID_CODE;
    }

    /**
     * @param string $token
     * @return string
     * @throws Exception
     */
    protected function getEmailFromDirectToken($token)
    {
        return $this->getPrimaryEmailFromGithub($token);
    }

    // -------------------------------------------------------------------------
    // GitHub-specific helpers
    // -------------------------------------------------------------------------

    /**
     * @param string $token
     * @return bool
     */
    private function isTokenIssuedForThisApp($token)
    {
        $clientId    = (string) $this->getClientId();
        $statusCode  = 400;
        $plainResult = '';
        $check = ServerCall::post(
            sprintf(self::CHECK_TOKEN_ENDPOINT_TPL, rawurlencode($clientId)),
            [
                'headers' => [
                    'Authorization' => 'Basic ' . base64_encode($clientId . ':' . $this->getClientSecret()),
                    'User-Agent'    => self::USER_AGENT,
                    'Accept'        => 'application/vnd.github+json',
                    'Content-Type'  => 'application/json',
                ],
                'body' => wp_json_encode(['access_token' => $token]),
            ],
            $statusCode,
            $plainResult
        );

        return $statusCode === 200
            && isset($check['app']['client_id'])
            && (string) $check['app']['client_id'] === $clientId;
    }

    /**
     * Retrieve the user's primary verified email from GitHub's /user/emails endpoint.
     *
     * @param string $accessToken
     * @return string
     * @throws Exception
     */
    private function getPrimaryEmailFromGithub($accessToken)
    {
        $statusCode  = 400;
        $plainResult = '';
        $emails = ServerCall::get(
            self::USERINFO_ENDPOINT,
            [
                'headers' => [
                    'Authorization' => 'Bearer ' . $accessToken,
                    'User-Agent'    => self::USER_AGENT,
                    'Accept'        => 'application/vnd.github+json',
                ],
            ],
            $statusCode,
            $plainResult
        );

        if ($statusCode !== 200 || !is_array($emails)) {
            throw new Exception(
                esc_html(__('Unable to retrieve user email from GitHub.', 'simple-jwt-login')),
                absint(ErrorCodes::ERR_GITHUB_INVALID_TOKEN)
            );
        }

        $allowUnverified = $this->settings->getIntegrationsSettings()->github()->allowUnverifiedEmail();
        foreach ($emails as $entry) {
            if (empty($entry['primary']) || empty($entry['email'])) {
                continue;
            }
            if (!empty($entry['verified']) || $allowUnverified) {
                return $entry['email'];
            }
        }

        if (!$allowUnverified) {
            throw new Exception(
                esc_html(__('No verified primary email found in the GitHub account.', 'simple-jwt-login')),
                absint(ErrorCodes::ERR_GITHUB_EMAIL_NOT_VERIFIED)
            );
        }

        throw new Exception(
            esc_html(__('No primary email found in the GitHub account.', 'simple-jwt-login')),
            absint(ErrorCodes::ERR_GITHUB_INVALID_TOKEN)
        );
    }
}
