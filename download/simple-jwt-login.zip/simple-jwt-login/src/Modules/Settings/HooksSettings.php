<?php

namespace SimpleJWTLogin\Modules\Settings;

class HooksSettings extends BaseSettings implements SettingsInterface
{
    protected function getSectionKey()
    {
        return 'hooks';
    }

    protected function getFieldDefinitions()
    {
        return [
            [null, 'enabled_hooks', null, 'enabled_hooks', self::SETTINGS_TYPE_ARRAY],
        ];
    }

    public function validateSettings()
    {
    }

    /**
     * @return array
     */
    public function getEnabledHooks()
    {
        return isset($this->settings['enabled_hooks'])
            ? (array)$this->settings['enabled_hooks']
            : [];
    }

    /**
     * @param string $hookName
     * @return bool
     */
    public function isHookEnabled($hookName)
    {
        return !empty($this->settings['enabled_hooks'])
            && in_array($hookName, $this->settings['enabled_hooks'], true);
    }
}
