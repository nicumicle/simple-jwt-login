<?php

if (! defined('ABSPATH')) {
    /** @phpstan-ignore-next-line  */
    exit;
} // Exit if accessed directly

use SimpleJWTLogin\Helpers\ServerHelper;
use SimpleJWTLogin\Helpers\StatusCodeHelper;
use SimpleJWTLogin\Libraries\ParseRequest;
use SimpleJWTLogin\Modules\SimpleJWTLoginSettings;
use SimpleJWTLogin\Repositories\Wordpress\WordPressRepository;
use SimpleJWTLogin\Routes\SessionService;
use SimpleJWTLogin\Services\RouteService;

// This will allow to log in  a user to WPGraphQL is not authenticated
add_action('init_graphql_request', function () {
    $wordPressReo = WordPressRepository::getInstance();
    $jwtSettings = new SimpleJWTLoginSettings($wordPressReo);
    if (!$jwtSettings->getIntegrationsSettings()->wpgraphql()->isEnabled()) {
        return;
    }
    $parseRequest = ParseRequest::process($_SERVER);
    $parsedRequestVariables = [];
    if (isset($parseRequest['variables'])) {
        $parsedRequestVariables = (array) $parseRequest['variables'];
    }

    $routeService = (new RouteService())
        ->withSettings($jwtSettings)
        //phpcs:ignore WordPress.Security.NonceVerification.Recommended
        ->withRequest(array_merge($_REQUEST, $parsedRequestVariables))
        ->withCookies($_COOKIE)
        ->withServerHelper(
            $jwtSettings->getGeneralSettings()->isTrustIpHeadersEnabled()
                ? ServerHelper::withTrustedProxyHeaders($_SERVER)
                : new ServerHelper($_SERVER)
        );

    if ($jwtSettings->getGeneralSettings()->isJwtFromSessionEnabled()) {
        $routeService->withSession(SessionService::init());
    }
    // Check if user is already authenticated
    if (is_user_logged_in()) {
        return;
    }

    $jwt = $routeService->getJwtFromRequestHeaderOrCookie();
    if (empty($jwt)) {
        return;
    }

    try {
        $wordPressReo
            ->loginUser(
                $routeService->getUserFromJwt($jwt),
                null
            );
        return true;
    } catch (\Exception $exception) {
        wp_send_json_error(
            [
                'message'    => $exception->getMessage(),
                'error_code' => $exception->getCode(),
                'type'      => 'simple-jwt-login-middleware'
            ],
            StatusCodeHelper::getStatusCodeFromException($exception)
        );

        return;
    }
});
