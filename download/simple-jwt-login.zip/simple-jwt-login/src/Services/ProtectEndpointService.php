<?php

namespace SimpleJWTLogin\Services;

use Exception;
use SimpleJWTLogin\ErrorCodes;
use SimpleJWTLogin\Helpers\ApiKeyPermissions;
use SimpleJWTLogin\Middleware\ApiKeyAuthMiddleware;
use SimpleJWTLogin\Modules\Settings\ProtectEndpointSettings;
use SimpleJWTLogin\Repositories\ApiKey\ApiKeyRepositoryInterface;

class ProtectEndpointService extends BaseService
{
    /**
     * @var RouteService $routeService
     */
    private $routeService;

    /**
     * @var ApiKeyRepositoryInterface|null
     */
    private $apiKeyRepository;

    /**
     * @param RouteService $routeService
     *
     * @return $this
     */
    public function withRouteService($routeService)
    {
        $this->routeService = $routeService;

        return $this;
    }

    /**
     * @param ApiKeyRepositoryInterface $repository
     *
     * @return $this
     */
    public function withApiKeyRepository($repository)
    {
        $this->apiKeyRepository = $repository;

        return $this;
    }

    /**
     * @param string $route The route WordPress dispatches (WP_REST_Request::get_route()).
     *                      Never derive it from the URL: /index.php/wp-json/..., ?rest_route=
     *                      and /wp-json/... all reach the same route.
     *
     * @throws Exception
     * @return bool
     */
    public function hasAccess($route)
    {
        if (!$this->jwtSettings->getProtectEndpointsSettings()->isEnabled()) {
            return true;
        }

        $isEndpointsProtected = true;
        $requiredRoles = [];
        if (!empty(trim((string) $route, '/'))) {
            $endpointInfo = $this->isEndpointProtected((string) $route);
            $isEndpointsProtected = $endpointInfo['protected'];
            $requiredRoles = $endpointInfo['roles'];
        }
        if (!$isEndpointsProtected) {
            return true;
        }

        // WordPress Core (block editor) and other plugins call the REST API with
        // cookie + nonce authentication. Accept the logged-in user, but only after
        // the endpoint rule has been resolved, so "JWT + Roles" rules are still enforced.
        if ($this->wordPressData->isUserLoggedIn()
            && $this->userHasRequiredRole(
                $this->wordPressData->getUserDetailsById($this->wordPressData->getCurrentUserId()),
                $requiredRoles
            )
        ) {
            return true;
        }

        try {
            $jwt = $this->getJwtFromRequestHeaderOrCookie();
            if (empty($jwt)) {
                throw new Exception(
                    __('JWT is not present and we can not search for a user.', 'simple-jwt-login'),
                    ErrorCodes::ERR_PROTECT_ENDPOINTS_MISSING_JWT
                );
            }

            // getUserFromJwt() already rejects revoked tokens.
            $user = $this->routeService->getUserFromJwt($jwt);

            $this->wordPressData->setCurrentUser($user);

            if (!$this->userHasRequiredRole($user, $requiredRoles)) {
                throw new Exception(
                    __('You do not have the required role to access this endpoint.', 'simple-jwt-login'),
                    ErrorCodes::ERR_PROTECT_ENDPOINTS_INSUFFICIENT_ROLE
                );
            }

            return true;
        } catch (Exception $exception) {
            if ($exception->getCode() === ErrorCodes::ERR_REVOKED_TOKEN
                || $exception->getCode() === ErrorCodes::ERR_PROTECT_ENDPOINTS_INSUFFICIENT_ROLE
            ) {
                throw $exception;
            }
        }

        return $this->tryApiKeyAuth($requiredRoles);
    }

    /**
     * @param \WP_User|false|null $user
     * @param array $requiredRoles
     *
     * @return bool
     */
    protected function userHasRequiredRole($user, $requiredRoles)
    {
        if (empty($requiredRoles)) {
            return true;
        }
        if (empty($user)) {
            return false;
        }

        $userRoles = $this->wordPressData->getUserRoles($user);

        return !empty(array_intersect($userRoles, $requiredRoles));
    }

    /**
     * @param array $requiredRoles
     *
     * @return bool
     */
    private function tryApiKeyAuth($requiredRoles)
    {
        if ($this->apiKeyRepository === null) {
            return false;
        }

        if (!$this->jwtSettings->getApiKeysSettings()->isEnabled()) {
            return false;
        }

        $requiredPermission = ApiKeyPermissions::httpMethodToPermission($this->requestMethod);
        if ($requiredPermission === null) {
            return false;
        }

        $apiKeysSettings = $this->jwtSettings->getApiKeysSettings();
        $keyData = (new ApiKeyAuthMiddleware($this->apiKeyRepository, $apiKeysSettings))
            ->validate($this->serverHelper, $requiredPermission, $apiKeysSettings->getHeaderName());

        if ($keyData === null) {
            return false;
        }

        $user = $this->wordPressData->getUserDetailsById((int) $keyData['user_id']);
        // The owner may have been deleted in wp-admin after the key was created.
        if (!$this->wordPressData->isInstanceOfuser($user) || !$this->userHasRequiredRole($user, $requiredRoles)) {
            return false;
        }
        $this->wordPressData->setCurrentUser($user);

        return true;
    }

    /**
     * Evaluates endpoint rules in order; the first matching rule wins.
     * Falls back to the configured default action when no rule matches.
     *
     * @param string $endpoint
     * @return array{protected: bool, roles: array}
     */
    private function isEndpointProtected($endpoint)
    {
        $notProtected = ['protected' => false, 'roles' => []];

        if (strpos($endpoint, '/') !== 0) {
            $endpoint = '/' . $endpoint;
        }

        $protectSettings = $this->jwtSettings->getProtectEndpointsSettings();
        $skipNamespace = '/' . trim(
            $this->jwtSettings->getGeneralSettings()->getRouteNamespace(),
            '/'
        );
        $endpoint = $this->removeLastSlash($endpoint);
        $adminPath = trim(
            str_replace($this->wordPressData->getSiteUrl(), '', $this->wordPressData->getAdminUrl()),
            '/'
        );
        if (strpos($endpoint, $skipNamespace) === 0
            || strpos(trim($endpoint, '/'), $adminPath) === 0) {
            return $notProtected;
        }

        $defaultProtected = $protectSettings->getDefaultAction() === ProtectEndpointSettings::DEFAULT_PROTECT_ALL;
        $cleanEndpoint = $this->removeWpJsonFromEndpoint($endpoint);

        foreach ($protectSettings->getRules() as $rule) {
            $ruleUrl = $this->removeWpJsonFromEndpoint($rule['url']);

            if (empty(trim($ruleUrl, '/'))) {
                continue;
            }

            $matched = strpos(strtolower($cleanEndpoint), strtolower($ruleUrl)) === 0;
            if ($rule['match'] === ProtectEndpointSettings::ENDPOINT_MATCH_EXACT) {
                $matched = strtolower($cleanEndpoint) === strtolower($ruleUrl);
            }

            if (!$matched) {
                continue;
            }

            $methodMatches = $rule['method'] === ProtectEndpointSettings::REQUEST_METHOD_ALL
                || $rule['method'] === $this->requestMethod;

            if (!$methodMatches) {
                continue;
            }

            if ($rule['type'] === ProtectEndpointSettings::RULE_TYPE_PUBLIC) {
                return $notProtected;
            }

            // Only enforce roles for "JWT + Roles" rules. A "JWT required" rule
            // must ignore any previously saved roles.
            $roles = $rule['type'] === ProtectEndpointSettings::RULE_TYPE_PROTECTED_ROLES
                && isset($rule['roles'])
                ? $rule['roles']
                : [];
            return ['protected' => true, 'roles' => $roles];
        }

        return ['protected' => $defaultProtected, 'roles' => []];
    }

    /**
     * The REST route of a rule URL, however it was saved: /wp-json/..., /index.php/wp-json/...,
     * /subdir/wp-json/..., a full URL or ?rest_route=..., matching WP_REST_Request::get_route().
     *
     * @param string $endpoint
     * @return string
     */
    private function removeWpJsonFromEndpoint($endpoint)
    {
        $endpoint = (string) $endpoint;
        $restRoutePos = strpos($endpoint, 'rest_route=');
        if ($restRoutePos !== false) {
            $route = strtok(urldecode(substr($endpoint, $restRoutePos + strlen('rest_route='))), '&');

            return $this->removeLastSlash((string) $route);
        }
        $wpJsonPos = strpos($endpoint, '/wp-json');
        if ($wpJsonPos !== false) {
            $endpoint = substr($endpoint, $wpJsonPos + strlen('/wp-json'));
        }

        return $this->removeLastSlash((string) $endpoint);
    }

    /**
     * @param string $endpoint
     * @return string
     */
    private function addFirstSlash($endpoint)
    {
        if (strpos($endpoint, '/') !== 0) {
            return '/' . $endpoint;
        }

        return $endpoint;
    }

    /**
     * @param string $endpoints
     * @return string
     */
    private function removeLastSlash($endpoints)
    {
        return $this->addFirstSlash(rtrim($endpoints, '/'));
    }
}
