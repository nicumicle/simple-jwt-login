<?php

namespace SimpleJWTLogin;

class SimpleJWTLogin {

    /**
     * Base file path for plugin code
     * @var string 
     */
    private $baseFilatPath;

    /**
     * @param string $basePath
     */
    public function __construct($basePath) 
    {
        $this->baseFilatPath = $basePath;
    }

    public function MainMenuPage() {
        $pluginData    = get_plugin_data($this->baseFilatPath);
        $pluginVersion = isset($pluginData['Version'])
            ? $pluginData['Version']
            : false;
        $pluginDirUrl = plugin_dir_url($this->baseFilatPath);
        $loadScriptsInFooter = false;

        wp_enqueue_style(
            'simple-jwt-login-bootstrap',
            $pluginDirUrl . 'vendor/bootstrap/bootstrap.min.css',
            [],
            $pluginVersion
        );
        wp_enqueue_style(
            'simple-jwt-login-style',
            $pluginDirUrl . 'css/style.css',
            [],
            $pluginVersion
        );
    
        wp_enqueue_script(
            'simple-jwt-bootstrap-min',
            $pluginDirUrl . 'vendor/bootstrap/bootstrap.min.js',
            [ 'jquery' ],
            $pluginVersion,
            $loadScriptsInFooter
        );
    
        wp_enqueue_script(
            'simple-jwt-login-scripts',
            $pluginDirUrl . 'js/scripts.js',
            [ 'simple-jwt-bootstrap-min' ],
            $pluginVersion,
            $loadScriptsInFooter
        );
    
        require_once('views/layout.php');
    }
}