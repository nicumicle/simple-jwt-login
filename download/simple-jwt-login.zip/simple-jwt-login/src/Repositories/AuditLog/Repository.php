<?php

namespace SimpleJWTLogin\Repositories\AuditLog;

interface Repository
{
    /**
     * @param string      $eventType
     * @param int|null    $userId
     * @param string|null $ipAddress
     * @param string      $status
     * @param string|null $message
     * @param int|null    $apiKeyId
     * @return bool
     */
    public function insert($eventType, $userId, $ipAddress, $status, $message, $apiKeyId = null);

    /**
     * Returns paginated log entries matching the given filters.
     *
     * Supported filter keys: event_type, status, user_id, user_email, date_from (Y-m-d), date_to (Y-m-d).
     * The user email is resolved by joining the WordPress users table on user_id.
     *
     * @param array $filters
     * @param int   $page    1-based page number
     * @param int   $perPage
     * @return array{items: object[], total: int}
     */
    public function findPaginated($filters, $page, $perPage);

    /**
     * Counts the entries of the last $hours hours, grouped by a fixed dimension.
     *
     * Dimensions: event, hour, day (all rows, grouped by status too) and
     * failure_ip, failure_user, failure_api_key, failure_message (failure rows only).
     * Each row has: bucket, status, total, users (distinct user ids), last_seen, user_email.
     *
     * @param string $dimension
     * @param int    $hours
     * @param int    $limit
     * @return object[]
     */
    public function aggregate($dimension, $hours, $limit);

    /**
     * Delete all entries older than the given datetime string (Y-m-d H:i:s).
     *
     * @param string $beforeDatetime
     * @return bool
     */
    public function deleteOlderThan($beforeDatetime);

    /**
     * Delete all audit log entries.
     *
     * @return bool
     */
    public function deleteAll();

    /**
     * Drop the audit logs table entirely (used on plugin uninstall).
     *
     * @return bool
     */
    public function dropTable();

    /**
     * Create (or upgrade) the audit logs table via dbDelta.
     *
     * @return void
     */
    public function createTable();
}
